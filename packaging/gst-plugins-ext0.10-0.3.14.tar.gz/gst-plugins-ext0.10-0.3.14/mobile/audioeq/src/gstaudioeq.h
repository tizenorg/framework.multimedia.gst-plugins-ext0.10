/*
 * audioeq
 *
 * Copyright (c) 2000 - 2012 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Contact: Aditi Narula <aditi.n@samsung.com>
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 51
 * Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 *
 */


#ifndef __GST_AUDIOEQ_H__
#define __GST_AUDIOEQ_H__

#include <stdio.h>
#include <gst/gst.h>
#include <gst/base/gstbasetransform.h>
#include <gst/audio/gstaudiofilter.h>
#include <gst/audio/gstringbuffer.h>
#include <gst/controller/gstcontroller.h>

G_BEGIN_DECLS

#define GST_TYPE_AUDIOEQ \
	(gst_audioeq_get_type())
#define GST_AUDIOEQ(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_AUDIOEQ,Gstaudioeq))
#define GST_audioeq_CLASS(klass) \
	(G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_AUDIOEQ,GstaudioeqClass))
#define GST_IS_AUDIOEQ(obj) \
	(G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_AUDIOEQ))
#define GST_IS_AUDIOEQ_CLASS(klass) \
	(G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_AUDIOEQ))
#define GST_TYPE_IIR_EQUALIZER \
  (gst_iir_equalizer_get_type())
#define GST_IIR_EQUALIZER(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_IIR_EQUALIZER,GstIirEqualizer))
#define GST_IIR_EQUALIZER_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_IIR_EQUALIZER,GstIirEqualizerClass))
#define GST_IS_IIR_EQUALIZER(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_IIR_EQUALIZER))
#define GST_IS_IIR_EQUALIZER_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_IIR_EQUALIZER))

typedef struct _Gstaudioeq Gstaudioeq;
typedef struct _GstaudioeqClass GstaudioeqClass;
typedef struct _GstIirEqualizer GstIirEqualizer;
typedef struct _GstIirEqualizerClass GstIirEqualizerClass;
typedef struct _GstIirEqualizerBand GstIirEqualizerBand;

#define CUSTOM_EQ_BAND_MAX				9

#define LOWEST_FREQ (20.0)
#define HIGHEST_FREQ (20000.0)

typedef void (*ProcessFunc) (GstIirEqualizer * eq, guint8 * data, guint size,
    guint channels);

struct _GstIirEqualizer
{
  GstAudioFilter audiofilter;

  /*< private >*/

  GMutex *bands_lock;
  GstIirEqualizerBand **bands;

  /* properties */
  guint freq_band_count;
  /* for each band and channel */
  gpointer history;
  guint history_size;

  gboolean need_new_coefficients;

  ProcessFunc process;
};

struct _GstIirEqualizerClass
{
  GstAudioFilterClass audiofilter_class;
};



struct _Gstaudioeq
{
	GstBaseTransform element;

	guint		samplerate;
	guint		channels;

	/* properties */
	guint		filter_action;
	gint			custom_eq[CUSTOM_EQ_BAND_MAX];
	gboolean		need_update_filter;
	GstIirEqualizer equ;
};

struct _GstaudioeqClass
{
	GstAudioFilterClass parent_class;
};

void gst_iir_equalizer_compute_frequencies (Gstaudioeq * audioeq, guint new_count);

GType gst_iir_equalizer_get_type(void);

GType gst_audioeq_get_type (void);

G_END_DECLS

#endif /* __GST_AUDIOEQ_H__ */

